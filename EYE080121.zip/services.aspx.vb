﻿
Partial Class services
    Inherits System.Web.UI.Page

End Class
