﻿
Partial Class pricing
    Inherits System.Web.UI.Page

End Class
