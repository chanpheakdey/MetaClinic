﻿
Partial Class department
    Inherits System.Web.UI.Page

End Class
