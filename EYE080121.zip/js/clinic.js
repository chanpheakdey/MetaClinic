﻿function GetHeaderMedia() {
    console.log("start GetHeaderMedia")
    $.ajax({
        cache: false,
        async: false,
        type: "POST",
        dataType: "Json",
        contentType: "application/json; charset=utf-8",
        url: "clinicservice.asmx/GetHeaderMedia",
        data: '',
        complete: function () {
            
        },
        success: function (data) {
            console.log(data.d);
            $(".py-1").html(data.d);
        },
        error: function (result) {
            console.log(result);
        }
    });
}

function GetHeaderContact() {
    $.ajax({
        cache: false,
        async: false,
        type: "POST",
        dataType: "Json",
        contentType: "application/json; charset=utf-8",
        url: "ClinicService.asmx/GetHeaderContact",
        data: '',
        complete: function () {

        },
        success: function (data) {
            console.log(data.d);
            $(".myheadercontact").html(data.d);
        },
        error: function (result) {
            console.log(result);
        }
    });
}


function GetHeaderMenu(menu) {
    $.ajax({
        cache: false,
        async: false,
        type: "POST",
        dataType: "Json",
        contentType: "application/json; charset=utf-8",
        url: "ClinicService.asmx/GetHeaderMenu",
        data: '{Menu:"' + menu + '"}',
        complete: function () {

        },
        success: function (data) {
            console.log(data.d);
            $("#ftco-navbar").html(data.d);
        },
        error: function (result) {
            console.log(result);
        }
    });
}
function loaddata() {
    //var fullurl = window.location.href;
    //var hostname = window.location.hostname;
    var menuname = window.location.pathname;
    GetHeaderMedia();
    GetHeaderContact();
    GetHeaderMenu(menuname);
}