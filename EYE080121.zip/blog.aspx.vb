﻿
Partial Class blog
    Inherits System.Web.UI.Page

End Class
