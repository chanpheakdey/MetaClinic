﻿
Partial Class doctors
    Inherits System.Web.UI.Page

End Class
